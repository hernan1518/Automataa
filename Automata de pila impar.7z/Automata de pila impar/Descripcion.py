des=[]
lin='           Automata de de pila que tiene la'
lin1='          funcionalidad de reconocer un palindromo de largo'
lin2='          impar, donde el caracter central C es un separador que'
lin3='          no esta presente en el prefijo que lo antecede. Es decir'
lin4='          la cadena a ser aceptada toma la forma l= ZcZ¨'
lin5='          donde Z pertenece a {a, b}*'
lin6='          Esto siendo P el estado 1, Q el estado 2 y R el estado final'


des.append(lin)
des.append(lin1)
des.append(lin2)
des.append(lin3)
des.append(lin4)
des.append(lin5)
des.append('   ')
des.append(lin6)
