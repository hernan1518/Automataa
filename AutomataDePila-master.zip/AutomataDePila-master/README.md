# AutomataDePila
Un autómata de pila que reconoce las palabras que son palindrome
