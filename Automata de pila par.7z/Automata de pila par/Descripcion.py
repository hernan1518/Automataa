des=[]
lin='Descripcion: este es un automatade de pila que tiene la'
lin1='          funcionalidad de reconocer un palindromo de largo'
lin2='          par, donde no hay caracter central, lo que aplica que'
lin4='          la cadena a ser aceptada toma la forma generar L= ZZ¨'
lin5='          donde Z pertenece a {a, b}*'
lin6='          Esto siendo P el estado 1, Q el estado 2 y R el estado final'


des.append(lin)
des.append(lin1)
des.append(lin2)
des.append(lin4)
des.append(lin5)
des.append('   ')
des.append(lin6)
